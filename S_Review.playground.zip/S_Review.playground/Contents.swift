/*: - Copyright :  Bulldog Ventures Inc  ©  2020 */
import UIKit

/*:

- Variables

Create a variable called name and initialize it to the name of your favorite actor, singer, or sports celebrity */
var crocAddict = "Find help please"
print(crocAddict)
/*:
- Displaying on the screen

Display the contents of name on the screen

 Change the value of name to your name*/
var name = "Etornam"
print(name)
/*:
- Constants
 
Display the contents of name

Create a constant (let instead of var) called language and initialize it to "Swift"

Display the contents of the language constant on screen

Create 3 different constants and initialize them to hold integers of your choice. Name the constants a, b, and c

Create 3 constants that are doubles (they have decimal points) Initialize them with values of your choice. Name the constants d, e, and f*/
let language = "Swift"
let constantA = "6"
print(constantA)

let constantB = "4"
print(constantB)

let  constantC = "8"
print(constantC)
 
let constantD = "3.9"
print(constantD)

let constantE = "5.6"
print(constantE)

let constantF = "1.8"
print(constantF)
/*:
- Operators

Create an assortment of statements using the constants that you created that will perform the following actions - then display the equation and the result on the screen.*/
var num1 = 75
var num2 = 3
var num3 = 9
var num4 = 5
var num5 = 11
var num6 = 66
var num7 = 4
var num8 = 2
var add = (num1 + num4)
var subtract = (num7 - num8)
var multiply = (num2 * num3)
var divide = (num6 / num5)
/*:
- Add two constants
 
-                print("a + b = " ) + (a + b)

Addition sample with at least 4 constants

Subtraction sample

Division sample

Multiplication sample*/
print( num3 + num2 + num8 + num1)
print( num1 - num8 - num2 - num7 )
print( num6 / num2 / num5 / num8)
print( num8 * num2 * num4 * num7)
/*:
- If Statements
 
Use the following constants to solve the problems :*/
 
let temperature = 80
let raining = true
let time = "Morning"
/*: Write a statement that tells someone to wear shorts if it is over 80 degrees, and jeans if it is less than 80 degrees. Check with the temperature constant

Check the raining constant and tell the user if they need an umbrella or not

Check the time constant and if it is morning tell the user to go to school, if it is afternoon tell the user to go home, and if it is night tell the user to go to bed*/
    if temperature >= 80  {
        print("Il fait chaud mon ami. Wear shorts")
    }

    else { print("Il fait froid! Wear jeans")
    }

     if raining {
        print ("You need an umbrella!")
     }  else {
        print ("It's not raining")
     }
        
        if time == "Morning" {
            print ("It's time for school")
        } else  {
            print ("It's time for bed")
        }
/*:
- Loops

Using a for loop print the numbers from 1 to 10 on screen

Using  a while loop print the numbers from 10 to 1 on screen*/
for Index in (1...10){
    print(Index)
}

var count = 10
while (count >= 1 ) {
    print(count)
    count-=1
}
/*:
- Collections

Create an array that holds five strings

Create a tuple that holds two strings

Using a loop, step through one of the collections you created and print all of the items to the screen*/
var fruits: [String] = ["Apple", "Bannana", "Orange", "Pineapple", "Strawberry"]
/*:
- Functions

Create a function that takes two doubles, multiplies them, and returns the result.

Call the function, save the result in the variable "answer". Pass it two of the constants you  creataed (a, b, c, d, e, or f)*/
func multiply(Num2: Int, Num7: Int) -> Int{
    return Num2 + Num7
}
print (multiply(Num2: Int(3), Num7: Int(4)))
/*:
- Closures

Create a closure that subtracts one number from another and prints the results, use the closure. You may pass it constants or numbers*/
var Subtract = {(Num6: Int, Num2: Int) -> Int in
    return Num6 - Num2
}
let difference = Subtract(75, 5)
print(difference)
/*:
- Enums
 
Create an enum that holds the first name of everyone in your group

Create a switch statement based on the enum that will display the birthday of the
selected person

Test it by using your own name*/
enum FirstName{
      case Etornam
      case Mehwish
      case Marwa
      case Ivy
}
var displayBirthday = FirstName.Etornam
var displayB1rthday = FirstName.Mehwish
var displayBirthdAy = FirstName.Marwa
var displayBirthdaY = FirstName.Ivy

switch displayBirthday {

case.Etornam:
    print ("April 19th")
case.Mehwish:
    print ("August 23rd")
case.Marwa:
    print ("January 2nd")
case.Ivy:
    print ("August 11th")
}
/*:
- Structure
 
Create a structure called Name that holds a first, middle, and last name and prints them on screen in one line with spaces between them

Create an instance of the Name structure, pass it your name, and use the instance you created to print your  name to the screen*/
struct Name {
    var first : String
    var middle : String
    var last : String
}
var nameStructure = Name (first: "Etornam", middle: "Ama", last: "Adevor")

print(nameStructure.first)
print(nameStructure.middle)
print(nameStructure.last)
/*:
- Class
 
Create a class called Coffee that accepts size, caffineated,  cream,  and sugar then prints the order on screen

Create an instance of the class

Use the instance of the class and call the function*/
class Coffee {
    var size: String
    var caffienated: String
    var cream: String
    var sugar: String
    
    init(size: String, caffienated: String, cream: String, sugar: String) {
    self.size = size
    self.caffienated = caffienated
    self.cream = cream
    self.sugar = sugar
}
    
    func order (){
        print("Etornam you're order is here!")
    }
}
var myOrder = Coffee(size: "small", caffienated: "espresso", cream: "french vanilla", sugar: "honey" )
myOrder.size
myOrder.caffienated
myOrder.cream
myOrder.sugar
myOrder.order()
